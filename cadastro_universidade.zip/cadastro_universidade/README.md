# Cadastro Universidade (Web)

Aplicação web (Flask) para o banco de dados **Universidade**, com:

- CRUD de **Alunos**, **Professores**, **Matérias** e **Cursos**;
- **Matrícula** do aluno (INSERT na tabela MATRICULA, igual ao script `INSERT MATRICULA.sql`);
- **Lançamento de Notas e Faltas** por bimestre, executando a procedure
  `sp_CadastraNotas` (igual ao script `EXEC sp_CadastraNotas.sql`).

## Estrutura do projeto

```
cadastro_universidade/
├── app.py              # Rotas Flask
├── data.py             # Acesso a dados (SQL / chamada da procedure)
├── db.py               # Conexão com o SQL Server
├── requirements.txt
├── templates/
│   ├── base.html
│   ├── alunos_lista.html
│   ├── aluno_form.html
│   ├── professores_lista.html
│   ├── professor_form.html
│   ├── materias_lista.html
│   ├── materia_form.html
│   ├── cursos_lista.html
│   ├── curso_form.html
│   ├── matriculas.html
│   └── notas.html
└── static/
```

> **Importante:** extraia o `.zip` mantendo a pasta `templates/` junto de `app.py`
> (não baixe os arquivos separadamente) — o Flask procura os templates dentro
> dessa pasta, no mesmo diretório do `app.py`.

## Pré-requisitos

1. **Python 3.9+**
2. **Driver ODBC para SQL Server** instalado no sistema:
   - Windows: [ODBC Driver 17 ou 18 for SQL Server](https://learn.microsoft.com/sql/connect/odbc/download-odbc-driver-for-sql-server)
   - Linux: pacote `msodbcsql17`/`msodbcsql18` + `unixodbc`
3. O banco **Universidade** já criado no SQL Server, com as tabelas
   `ALUNOS`, `CURSOS`, `PROFESSOR`, `MATERIAS`, `MATRICULA` e a procedure
   `sp_CadastraNotas` (conforme os scripts fornecidos).

## Instalação

```bash
cd cadastro_universidade
pip install -r requirements.txt
```

## Configuração da conexão

Edite `db.py` e ajuste o dicionário `DB_CONFIG`:

```python
DB_CONFIG = {
    "driver": "{ODBC Driver 17 for SQL Server}",
    "server": "localhost",        # ou "localhost\\SQLEXPRESS", IP, etc.
    "database": "Universidade",
    "trusted_connection": "yes",  # autenticação do Windows
    # Para autenticação SQL Server, comente a linha acima e use:
    # "uid": "seu_usuario",
    # "pwd": "sua_senha",
}
```

## Executando

```bash
python app.py
```

Acesse **http://localhost:5000** no navegador.

## Telas e rotas

| Rota                         | Descrição                                           |
|------------------------------|------------------------------------------------------|
| `/alunos`                    | Lista/busca de alunos                                |
| `/alunos/novo`                | Cadastro de novo aluno                               |
| `/alunos/<matricula>/editar`  | Edição de aluno                                      |
| `/professores`                | Lista/busca de professores                           |
| `/professores/novo`           | Cadastro de novo professor                           |
| `/professores/<codigo>/editar`| Edição de professor                                  |
| `/materias`                   | Lista/busca de matérias                              |
| `/materias/novo`              | Cadastro de nova matéria (escolhe curso e professor) |
| `/materias/<sigla>/editar`    | Edição de matéria                                    |
| `/cursos`                     | Lista de cursos                                      |
| `/cursos/novo`                 | Cadastro de novo curso                               |
| `/cursos/<codigo>/editar`      | Edição de curso                                      |
| `/matriculas`                  | Matricular aluno em curso/matéria/professor/período  |
| `/notas`                       | Lançar nota e faltas de um bimestre (EXEC procedure) |

## Sobre a tela "Matrícula"

Reproduz exatamente o `INSERT MATRICULA.sql` fornecido:

```sql
INSERT MATRICULA (MATRICULA, CURSO, MATERIA, PROFESSOR, PERLETIVO)
VALUES (?, ?, ?, ?, ?)
```

O aluno precisa estar matriculado **antes** de ser possível lançar notas para
ele naquele curso/matéria/período (a procedure `sp_CadastraNotas` só
atualiza uma linha que já existe em `MATRICULA`).

## Sobre a tela "Lançar Notas"

Executa a procedure `sp_CadastraNotas` via `pyodbc`:

```sql
EXEC sp_CadastraNotas @MATRICULA = ?, @CURSO = ?, @MATERIA = ?,
                      @PERLETIVO = ?, @NOTA = ?, @FALTA = ?, @BIMESTRE = ?
```

Após a execução, a página mostra a linha atual de `MATRICULA` retornada pela
procedure (o `SELECT * FROM MATRICULA WHERE MATRICULA = @MATRICULA` que está
no final da procedure).

**Observação:** a procedure, como fornecida, só preenche as colunas `N1..N4`,
`F1..F4`, `TOTALPONTOS`, `TOTALFALTAS` e `MEDIA`. As colunas `RESULTADO`,
`PERCFREQ`, `MEDIAFINAL` e `NOTAEXAME` não são calculadas por ela (no 4º
bimestre ela declara variáveis para isso, mas não chega a usá-las nos
comandos `UPDATE`) — esse comportamento foi mantido fiel ao script original,
sem alterações na lógica da procedure.

## Observações gerais

- O código do curso (`CURSO`) e a sigla da matéria (`SIGLA`) têm 3
  caracteres, conforme definido no banco (`CHAR(3)`).
- `PERLETIVO`, ao chamar a procedure, é enviado como texto (`CHAR(4)`),
  exatamente como no script `EXEC sp_CadastraNotas.sql`.
- Assim como nos projetos anteriores, por segurança, nunca comite usuário e
  senha reais em `db.py` — prefira variáveis de ambiente em produção.
