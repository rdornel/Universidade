"""
Aplicação Web (Flask) para o banco de dados Universidade.

Funcionalidades:
- CRUD de Alunos, Professores, Matérias (e Cursos, para suporte às FKs)
- Matrícula do aluno em uma matéria/curso/professor/período (INSERT MATRICULA)
- Lançamento de notas e faltas por bimestre (EXEC sp_CadastraNotas)
"""

from flask import Flask, render_template, request, redirect, url_for, flash

import data

app = Flask(__name__)
app.secret_key = "troque-esta-chave-em-producao"


@app.route("/")
def index():
    return redirect(url_for("alunos_listar"))


# ---------------------------------------------------------------------------
# ALUNOS
# ---------------------------------------------------------------------------

@app.route("/alunos")
def alunos_listar():
    termo = request.args.get("q", "").strip()
    alunos = data.alunos_listar(termo or None)
    return render_template("alunos_lista.html", alunos=alunos, termo=termo)


@app.route("/alunos/novo", methods=["GET", "POST"])
def alunos_novo():
    if request.method == "POST":
        nome = request.form.get("NOME", "").strip()
        if not nome:
            flash("Informe o nome do aluno.", "warning")
            return render_template("aluno_form.html", titulo="Novo Aluno", aluno=None)
        matricula = data.aluno_inserir(nome)
        flash(f"Aluno cadastrado com matrícula {matricula}.", "success")
        return redirect(url_for("alunos_listar"))
    return render_template("aluno_form.html", titulo="Novo Aluno", aluno=None)


@app.route("/alunos/<int:matricula>/editar", methods=["GET", "POST"])
def alunos_editar(matricula):
    aluno = data.aluno_obter(matricula)
    if not aluno:
        flash("Aluno não encontrado.", "danger")
        return redirect(url_for("alunos_listar"))

    if request.method == "POST":
        nome = request.form.get("NOME", "").strip()
        if not nome:
            flash("Informe o nome do aluno.", "warning")
            return render_template("aluno_form.html", titulo="Editar Aluno", aluno=aluno)
        data.aluno_atualizar(matricula, nome)
        flash("Aluno atualizado com sucesso.", "success")
        return redirect(url_for("alunos_listar"))

    return render_template("aluno_form.html", titulo="Editar Aluno", aluno=aluno)


# ---------------------------------------------------------------------------
# CURSOS
# ---------------------------------------------------------------------------

@app.route("/cursos")
def cursos_listar():
    cursos = data.cursos_listar()
    return render_template("cursos_lista.html", cursos=cursos)


@app.route("/cursos/novo", methods=["GET", "POST"])
def cursos_novo():
    if request.method == "POST":
        curso = request.form.get("CURSO", "").strip().upper()
        nome = request.form.get("NOME", "").strip()
        if not curso or not nome:
            flash("Informe o código (3 letras) e o nome do curso.", "warning")
            return render_template("curso_form.html", titulo="Novo Curso", curso=None)
        if len(curso) != 3:
            flash("O código do curso deve ter exatamente 3 caracteres.", "warning")
            return render_template("curso_form.html", titulo="Novo Curso", curso=None)
        data.curso_inserir(curso, nome)
        flash("Curso cadastrado com sucesso.", "success")
        return redirect(url_for("cursos_listar"))
    return render_template("curso_form.html", titulo="Novo Curso", curso=None)


@app.route("/cursos/<codigo>/editar", methods=["GET", "POST"])
def cursos_editar(codigo):
    curso = data.curso_obter(codigo)
    if not curso:
        flash("Curso não encontrado.", "danger")
        return redirect(url_for("cursos_listar"))

    if request.method == "POST":
        nome = request.form.get("NOME", "").strip()
        if not nome:
            flash("Informe o nome do curso.", "warning")
            return render_template("curso_form.html", titulo="Editar Curso", curso=curso)
        data.curso_atualizar(codigo, nome)
        flash("Curso atualizado com sucesso.", "success")
        return redirect(url_for("cursos_listar"))

    return render_template("curso_form.html", titulo="Editar Curso", curso=curso)


# ---------------------------------------------------------------------------
# PROFESSORES
# ---------------------------------------------------------------------------

@app.route("/professores")
def professores_listar():
    termo = request.args.get("q", "").strip()
    professores = data.professores_listar(termo or None)
    return render_template("professores_lista.html", professores=professores, termo=termo)


@app.route("/professores/novo", methods=["GET", "POST"])
def professores_novo():
    if request.method == "POST":
        nome = request.form.get("NOME", "").strip()
        if not nome:
            flash("Informe o nome do professor.", "warning")
            return render_template("professor_form.html", titulo="Novo Professor", professor=None)
        codigo = data.professor_inserir(nome)
        flash(f"Professor cadastrado com código {codigo}.", "success")
        return redirect(url_for("professores_listar"))
    return render_template("professor_form.html", titulo="Novo Professor", professor=None)


@app.route("/professores/<int:codigo>/editar", methods=["GET", "POST"])
def professores_editar(codigo):
    professor = data.professor_obter(codigo)
    if not professor:
        flash("Professor não encontrado.", "danger")
        return redirect(url_for("professores_listar"))

    if request.method == "POST":
        nome = request.form.get("NOME", "").strip()
        if not nome:
            flash("Informe o nome do professor.", "warning")
            return render_template("professor_form.html", titulo="Editar Professor", professor=professor)
        data.professor_atualizar(codigo, nome)
        flash("Professor atualizado com sucesso.", "success")
        return redirect(url_for("professores_listar"))

    return render_template("professor_form.html", titulo="Editar Professor", professor=professor)


# ---------------------------------------------------------------------------
# MATERIAS
# ---------------------------------------------------------------------------

@app.route("/materias")
def materias_listar():
    termo = request.args.get("q", "").strip()
    materias = data.materias_listar(termo or None)
    return render_template("materias_lista.html", materias=materias, termo=termo)


@app.route("/materias/novo", methods=["GET", "POST"])
def materias_novo():
    cursos = data.cursos_listar()
    professores = data.professores_listar()

    if request.method == "POST":
        sigla = request.form.get("SIGLA", "").strip().upper()
        nome = request.form.get("NOME", "").strip()
        carga_horaria = request.form.get("CARGAHORARIA", "").strip()
        curso = request.form.get("CURSO", "").strip()
        professor = request.form.get("PROFESSOR", "").strip()

        erro = None
        if not sigla or len(sigla) != 3:
            erro = "A sigla da matéria deve ter exatamente 3 caracteres."
        elif not nome:
            erro = "Informe o nome da matéria."
        elif not carga_horaria or not carga_horaria.isdigit():
            erro = "Informe a carga horária (somente números)."
        elif not curso:
            erro = "Selecione o curso."

        if erro:
            flash(erro, "warning")
            return render_template(
                "materia_form.html", titulo="Nova Matéria", materia=None,
                cursos=cursos, professores=professores,
            )

        data.materia_inserir(
            sigla, nome, int(carga_horaria), curso,
            int(professor) if professor else None,
        )
        flash("Matéria cadastrada com sucesso.", "success")
        return redirect(url_for("materias_listar"))

    return render_template(
        "materia_form.html", titulo="Nova Matéria", materia=None,
        cursos=cursos, professores=professores,
    )


@app.route("/materias/<sigla>/editar", methods=["GET", "POST"])
def materias_editar(sigla):
    materia = data.materia_obter(sigla)
    cursos = data.cursos_listar()
    professores = data.professores_listar()

    if not materia:
        flash("Matéria não encontrada.", "danger")
        return redirect(url_for("materias_listar"))

    if request.method == "POST":
        nome = request.form.get("NOME", "").strip()
        carga_horaria = request.form.get("CARGAHORARIA", "").strip()
        curso = request.form.get("CURSO", "").strip()
        professor = request.form.get("PROFESSOR", "").strip()

        erro = None
        if not nome:
            erro = "Informe o nome da matéria."
        elif not carga_horaria or not carga_horaria.isdigit():
            erro = "Informe a carga horária (somente números)."
        elif not curso:
            erro = "Selecione o curso."

        if erro:
            flash(erro, "warning")
            return render_template(
                "materia_form.html", titulo="Editar Matéria", materia=materia,
                cursos=cursos, professores=professores,
            )

        data.materia_atualizar(
            sigla, nome, int(carga_horaria), curso,
            int(professor) if professor else None,
        )
        flash("Matéria atualizada com sucesso.", "success")
        return redirect(url_for("materias_listar"))

    return render_template(
        "materia_form.html", titulo="Editar Matéria", materia=materia,
        cursos=cursos, professores=professores,
    )


# ---------------------------------------------------------------------------
# MATRICULA (enturmar aluno em curso/matéria/professor/período)
# ---------------------------------------------------------------------------

@app.route("/matriculas", methods=["GET", "POST"])
def matriculas_home():
    alunos = data.alunos_listar()
    cursos = data.cursos_listar()
    materias = data.materias_listar()
    professores = data.professores_listar()

    if request.method == "POST":
        matricula = request.form.get("MATRICULA", "").strip()
        curso = request.form.get("CURSO", "").strip()
        materia = request.form.get("MATERIA", "").strip()
        professor = request.form.get("PROFESSOR", "").strip()
        perletivo = request.form.get("PERLETIVO", "").strip()

        erro = None
        if not matricula or not matricula.isdigit():
            erro = "Selecione o aluno."
        elif not curso:
            erro = "Selecione o curso."
        elif not materia:
            erro = "Selecione a matéria."
        elif not professor or not professor.isdigit():
            erro = "Selecione o professor."
        elif not perletivo or not perletivo.isdigit():
            erro = "Informe o período letivo (ano), ex: 2025."

        if erro:
            flash(erro, "warning")
        else:
            try:
                data.matricula_inserir(
                    int(matricula), curso, materia, int(professor), int(perletivo)
                )
                flash("Aluno matriculado com sucesso.", "success")
            except Exception as exc:  # erro de FK/PK duplicada etc.
                flash(f"Não foi possível matricular: {exc}", "danger")

        return redirect(url_for("matriculas_home"))

    matriculas_existentes = data.matriculas_listar()
    return render_template(
        "matriculas.html",
        alunos=alunos, cursos=cursos, materias=materias, professores=professores,
        matriculas=matriculas_existentes,
    )


# ---------------------------------------------------------------------------
# LANÇAMENTO DE NOTAS (EXEC sp_CadastraNotas)
# ---------------------------------------------------------------------------

@app.route("/notas", methods=["GET", "POST"])
def notas_lancar():
    alunos = data.alunos_listar()
    cursos = data.cursos_listar()
    materias = data.materias_listar()

    resultado = None

    if request.method == "POST":
        matricula = request.form.get("MATRICULA", "").strip()
        curso = request.form.get("CURSO", "").strip()
        materia = request.form.get("MATERIA", "").strip()
        perletivo = request.form.get("PERLETIVO", "").strip()
        nota = request.form.get("NOTA", "").strip()
        falta = request.form.get("FALTA", "").strip()
        bimestre = request.form.get("BIMESTRE", "").strip()

        erro = None
        if not matricula or not matricula.isdigit():
            erro = "Selecione o aluno."
        elif not curso:
            erro = "Selecione o curso."
        elif not materia:
            erro = "Selecione a matéria."
        elif not perletivo:
            erro = "Informe o período letivo (ano), ex: 2025."
        elif not nota:
            erro = "Informe a nota."
        elif not falta:
            erro = "Informe a quantidade de faltas."
        elif bimestre not in ("1", "2", "3", "4"):
            erro = "Selecione o bimestre (1 a 4)."

        if erro:
            flash(erro, "warning")
        else:
            try:
                nota_float = float(nota.replace(",", "."))
                falta_int = int(falta)
                linhas = data.cadastrar_notas(
                    int(matricula), curso, materia, perletivo,
                    nota_float, falta_int, int(bimestre),
                )
                if linhas:
                    resultado = linhas[0]
                    flash("Nota/falta lançada com sucesso.", "success")
                else:
                    flash(
                        "A procedure foi executada, mas nenhuma matrícula "
                        "correspondente foi encontrada (verifique se o aluno "
                        "está matriculado nesse curso/matéria/período).",
                        "warning",
                    )
            except ValueError:
                flash("Nota inválida. Use um número, ex: 7.5", "warning")
            except Exception as exc:
                flash(f"Erro ao lançar nota: {exc}", "danger")

    return render_template(
        "notas.html",
        alunos=alunos, cursos=cursos, materias=materias, resultado=resultado,
    )


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
