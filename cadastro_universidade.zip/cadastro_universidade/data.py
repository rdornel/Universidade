"""
Camada de acesso a dados do banco Universidade.

Reúne as operações de CRUD para ALUNOS, PROFESSOR, MATERIAS e CURSOS,
além da matrícula (INSERT MATRICULA) e do lançamento de notas/faltas via
procedure sp_CadastraNotas.
"""

from db import get_connection


# ---------------------------------------------------------------------------
# ALUNOS
# ---------------------------------------------------------------------------

def alunos_listar(termo=None):
    """Lista alunos, opcionalmente filtrando pelo nome (busca parcial)."""
    conn = get_connection()
    cur = conn.cursor()
    try:
        if termo:
            cur.execute(
                "SELECT MATRICULA, NOME FROM ALUNOS WHERE NOME LIKE ? ORDER BY NOME",
                (f"%{termo}%",),
            )
        else:
            cur.execute("SELECT MATRICULA, NOME FROM ALUNOS ORDER BY NOME")
        return cur.fetchall()
    finally:
        conn.close()


def aluno_obter(matricula):
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute("SELECT MATRICULA, NOME FROM ALUNOS WHERE MATRICULA = ?", (matricula,))
        row = cur.fetchone()
        if not row:
            return None
        return {"MATRICULA": row[0], "NOME": row[1]}
    finally:
        conn.close()


def aluno_inserir(nome):
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute(
            "INSERT INTO ALUNOS (NOME) OUTPUT INSERTED.MATRICULA VALUES (?)",
            (nome,),
        )
        nova_matricula = cur.fetchone()[0]
        conn.commit()
        return nova_matricula
    finally:
        conn.close()


def aluno_atualizar(matricula, nome):
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute("UPDATE ALUNOS SET NOME = ? WHERE MATRICULA = ?", (nome, matricula))
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# CURSOS
# ---------------------------------------------------------------------------

def cursos_listar():
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute("SELECT CURSO, NOME FROM CURSOS ORDER BY NOME")
        return cur.fetchall()
    finally:
        conn.close()


def curso_obter(curso):
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute("SELECT CURSO, NOME FROM CURSOS WHERE CURSO = ?", (curso,))
        row = cur.fetchone()
        if not row:
            return None
        return {"CURSO": row[0], "NOME": row[1]}
    finally:
        conn.close()


def curso_inserir(curso, nome):
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute("INSERT INTO CURSOS (CURSO, NOME) VALUES (?, ?)", (curso, nome))
        conn.commit()
    finally:
        conn.close()


def curso_atualizar(curso, nome):
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute("UPDATE CURSOS SET NOME = ? WHERE CURSO = ?", (nome, curso))
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# PROFESSOR
# ---------------------------------------------------------------------------

def professores_listar(termo=None):
    conn = get_connection()
    cur = conn.cursor()
    try:
        if termo:
            cur.execute(
                "SELECT PROFESSOR, NOME FROM PROFESSOR WHERE NOME LIKE ? ORDER BY NOME",
                (f"%{termo}%",),
            )
        else:
            cur.execute("SELECT PROFESSOR, NOME FROM PROFESSOR ORDER BY NOME")
        return cur.fetchall()
    finally:
        conn.close()


def professor_obter(codigo):
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute("SELECT PROFESSOR, NOME FROM PROFESSOR WHERE PROFESSOR = ?", (codigo,))
        row = cur.fetchone()
        if not row:
            return None
        return {"PROFESSOR": row[0], "NOME": row[1]}
    finally:
        conn.close()


def professor_inserir(nome):
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute(
            "INSERT INTO PROFESSOR (NOME) OUTPUT INSERTED.PROFESSOR VALUES (?)",
            (nome,),
        )
        novo_codigo = cur.fetchone()[0]
        conn.commit()
        return novo_codigo
    finally:
        conn.close()


def professor_atualizar(codigo, nome):
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute("UPDATE PROFESSOR SET NOME = ? WHERE PROFESSOR = ?", (nome, codigo))
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# MATERIAS
# ---------------------------------------------------------------------------

def materias_listar(termo=None):
    """Lista matérias com nome do curso e do professor (joins para exibição)."""
    conn = get_connection()
    cur = conn.cursor()
    try:
        sql = (
            "SELECT M.SIGLA, M.NOME, M.CARGAHORARIA, M.CURSO, C.NOME, M.PROFESSOR, P.NOME "
            "FROM MATERIAS M "
            "LEFT JOIN CURSOS C ON C.CURSO = M.CURSO "
            "LEFT JOIN PROFESSOR P ON P.PROFESSOR = M.PROFESSOR "
        )
        if termo:
            sql += "WHERE M.NOME LIKE ? OR M.SIGLA LIKE ? ORDER BY M.NOME"
            cur.execute(sql, (f"%{termo}%", f"%{termo}%"))
        else:
            sql += "ORDER BY M.NOME"
            cur.execute(sql)
        return cur.fetchall()
    finally:
        conn.close()


def materia_obter(sigla):
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute(
            "SELECT SIGLA, NOME, CARGAHORARIA, CURSO, PROFESSOR FROM MATERIAS WHERE SIGLA = ?",
            (sigla,),
        )
        row = cur.fetchone()
        if not row:
            return None
        return {
            "SIGLA": row[0],
            "NOME": row[1],
            "CARGAHORARIA": row[2],
            "CURSO": row[3],
            "PROFESSOR": row[4],
        }
    finally:
        conn.close()


def materia_inserir(sigla, nome, carga_horaria, curso, professor):
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute(
            "INSERT INTO MATERIAS (SIGLA, NOME, CARGAHORARIA, CURSO, PROFESSOR) "
            "VALUES (?, ?, ?, ?, ?)",
            (sigla, nome, carga_horaria, curso, professor),
        )
        conn.commit()
    finally:
        conn.close()


def materia_atualizar(sigla, nome, carga_horaria, curso, professor):
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute(
            "UPDATE MATERIAS SET NOME = ?, CARGAHORARIA = ?, CURSO = ?, PROFESSOR = ? "
            "WHERE SIGLA = ?",
            (nome, carga_horaria, curso, professor, sigla),
        )
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# MATRICULA (enturmação do aluno em uma matéria/curso/professor/periodo)
# ---------------------------------------------------------------------------

def matricula_inserir(matricula, curso, materia, professor, perletivo):
    """
    Reproduz exatamente:
        INSERT MATRICULA (MATRICULA, CURSO, MATERIA, PROFESSOR, PERLETIVO)
        VALUES (?, ?, ?, ?, ?)
    """
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute(
            "INSERT INTO MATRICULA (MATRICULA, CURSO, MATERIA, PROFESSOR, PERLETIVO) "
            "VALUES (?, ?, ?, ?, ?)",
            (matricula, curso, materia, professor, perletivo),
        )
        conn.commit()
    finally:
        conn.close()


def matriculas_listar(matricula_aluno=None):
    """Lista as matrículas (enturmações) existentes, opcionalmente filtradas por aluno."""
    conn = get_connection()
    cur = conn.cursor()
    try:
        sql = (
            "SELECT MA.MATRICULA, A.NOME, MA.CURSO, MA.MATERIA, MAT.NOME, "
            "MA.PROFESSOR, P.NOME, MA.PERLETIVO, MA.MEDIA "
            "FROM MATRICULA MA "
            "LEFT JOIN ALUNOS A ON A.MATRICULA = MA.MATRICULA "
            "LEFT JOIN MATERIAS MAT ON MAT.SIGLA = MA.MATERIA "
            "LEFT JOIN PROFESSOR P ON P.PROFESSOR = MA.PROFESSOR "
        )
        if matricula_aluno:
            sql += "WHERE MA.MATRICULA = ? ORDER BY MA.PERLETIVO DESC, MAT.NOME"
            cur.execute(sql, (matricula_aluno,))
        else:
            sql += "ORDER BY MA.PERLETIVO DESC, A.NOME"
            cur.execute(sql)
        return cur.fetchall()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# sp_CadastraNotas
# ---------------------------------------------------------------------------

def cadastrar_notas(matricula, curso, materia, perletivo, nota, falta, bimestre):
    """
    Executa a procedure sp_CadastraNotas e retorna a linha de MATRICULA
    resultante (igual ao SELECT final da procedure), como uma lista de dicts
    (normalmente contém 1 linha).
    """
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute(
            "{CALL sp_CadastraNotas (?, ?, ?, ?, ?, ?, ?)}",
            (matricula, curso, materia, str(perletivo), nota, falta, bimestre),
        )
        colunas = [col[0] for col in cur.description] if cur.description else []
        linhas = cur.fetchall() if cur.description else []
        conn.commit()
        return [dict(zip(colunas, linha)) for linha in linhas]
    finally:
        conn.close()
